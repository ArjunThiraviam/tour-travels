import MobileMenu  from './modules/moblieMenu';

var mobileMenu = new MobileMenu;
